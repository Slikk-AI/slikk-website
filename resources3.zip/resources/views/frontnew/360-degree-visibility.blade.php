
<!DOCTYPE html>
<html lang="en">

	<!DOCTYPE html>
<html lang="en">
<head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="https://hub.slikk.ai/img/Slikk-Icon.svg">
<title>Best Project Management Tool With 360 Degree Visibility | Slikk</title>


<meta name="description" content="Best Project Management Software with 360 degree visibility. Slikk&#039;s 360 degree visibility offers a detailed view of your project. Click here to know more!">

<meta name="language" content="English">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="canonical" href="https://hub.slikk.ai/features/360-degree-visibility">


  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://www.emergenresearch.com/js/jquery.js"></script>
  
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&family=Roboto:wght@300&display=swap" rel="stylesheet">

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-W24QW8T');</script>
<!-- End Google Tag Manager -->

  <style>




:root {

/* Colors: */
--unnamed-color-6b52f9: #6B52F9;
--unnamed-color-ededf2: #EDEDF2;
--unnamed-color-ffffff: #FFFFFF;
--unnamed-color-2900ff: #2900FF;
--unnamed-color-6c63ff: #6C63FF;
--unnamed-color-fceeff: #FCEEFF;
--unnamed-color-6253b2: #6253B2;
--unnamed-color-5433ff: #5433FF;
--unnamed-color-1d2121: #1D2121;

/* Font/text values */
--unnamed-font-family-roboto: Roboto;
--unnamed-font-family-scandia: Scandia;
--unnamed-font-family-urbane-rounded: Urbane Rounded;
--unnamed-font-style-normal: normal;
--unnamed-font-weight-300: 300px;
--unnamed-font-weight-normal: normal;
--unnamed-font-weight-medium: medium;
--unnamed-font-weight-bold: bold;
--unnamed-font-size-14: 14px;
--unnamed-font-size-16: 16px;
--unnamed-font-size-18: 18px;
--unnamed-font-size-20: 20px;
--unnamed-font-size-25: 25px;
--unnamed-font-size-30: 30px;
--unnamed-font-size-36: 36px;
--unnamed-font-size-50: 50px;
--unnamed-character-spacing-0: 0px;
--unnamed-line-spacing-19: 19px;
--unnamed-line-spacing-21: 21px;
--unnamed-line-spacing-26: 26px;
--unnamed-line-spacing-30: 30px;
--unnamed-line-spacing-33: 33px;
--unnamed-line-spacing-39: 39px;
--unnamed-line-spacing-44: 44px;
--unnamed-line-spacing-60: 60px;
}

/* Character Styles */
.unnamed-character-style-1 {
font-family: var(--unnamed-font-family-scandia);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-medium);
font-size: var(--unnamed-font-size-50);
line-height: var(--unnamed-line-spacing-60);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-2 {
font-family: var(--unnamed-font-family-urbane-rounded);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-bold);
font-size: var(--unnamed-font-size-36);
line-height: var(--unnamed-line-spacing-44);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}
.unnamed-character-style-3 {
font-family: var(--unnamed-font-family-urbane-rounded);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-bold);
font-size: var(--unnamed-font-size-25);
line-height: var(--unnamed-line-spacing-30);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-4 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-medium);
font-size: var(--unnamed-font-size-20);
line-height: var(--unnamed-line-spacing-26);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-5 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-300);
font-size: var(--unnamed-font-size-18);
line-height: var(--unnamed-line-spacing-30);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-6 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-25);
line-height: var(--unnamed-line-spacing-33);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}
.unnamed-character-style-7 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-30);
line-height: var(--unnamed-line-spacing-39);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}
.unnamed-character-style-8 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-16);
line-height: var(--unnamed-line-spacing-21);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-9 {
font-family: var(--unnamed-font-family-urbane-rounded);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-bold);
font-size: var(--unnamed-font-size-50);
line-height: var(--unnamed-line-spacing-60);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-10 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-25);
line-height: var(--unnamed-line-spacing-33);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
}
.unnamed-character-style-11 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-16);
line-height: var(--unnamed-line-spacing-21);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}
.unnamed-character-style-12 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-normal);
font-size: var(--unnamed-font-size-14);
line-height: var(--unnamed-line-spacing-19);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}
.unnamed-character-style-13 {
font-family: var(--unnamed-font-family-roboto);
font-style: var(--unnamed-font-style-normal);
font-weight: var(--unnamed-font-weight-300);
font-size: var(--unnamed-font-size-14);
line-height: var(--unnamed-line-spacing-19);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
}

.navclass {
    background:#609CFC 0% 0% no-repeat padding-box !important;
}

.hero_title {
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) var(--unnamed-font-size-50)/var(--unnamed-line-spacing-60) var(--unnamed-font-family-urbane-rounded);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
text-align: left;
font: normal normal bold 35px/42px Urbane Rounded;
letter-spacing: 0px;
color: #FFFFFF;
opacity: 1;
}

.hero_desc {
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-25)/var(--unnamed-line-spacing-33) var(--unnamed-font-family-roboto);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
text-align: left;
font: normal normal normal 20px/23px Roboto;
letter-spacing: 0px;
color: #FFFFFF;
font-weight:100;
opacity: 1;

}

.section_title {
    font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-bold) 36px/44px var(--unnamed-font-family-urbane-rounded);
letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-1d2121);
text-align: center;
font: normal normal bold 36px/44px Urbane Rounded;
letter-spacing: 0px;
color: #1D2121;
opacity: 1;
}

.jumbotron {
    padding: 0px;
}

.section_title {
    font-family: 'Roboto', sans-serif;
}
.hero_title{
    font-family: 'Roboto', sans-serif;
}

.icon {
    width: 70px;
    margin-left: auto;
    margin-right: auto;
    margin-bottom:30px;
}

.icon img {
    width: 70px;

}

.icon-about {
    width: 100px;
    margin-left: auto;
    margin-right: auto;
    height: 100px;
    border-radius: 65px;
    box-shadow: 1px 3px 6px #00000029;
    background: #6B52F9 0% 0% no-repeat padding-box;
}

.box-title {
  text-align:center;
  padding-top: 10px;
  padding-bottom:10px;
  margin-right:auto;
  margin-left: auto;
  font-family: 'Roboto', sans-serif;
  font: normal normal normal 22px/26px Roboto;
letter-spacing: 0px;
color: #1D2121;


}

h3.timeline-title {
  text-align:center;
  padding-top: 10px;
  padding-bottom:10px;
  margin-right:auto;
  margin-left: auto;
  font-family: 'Roboto', sans-serif;
  font: normal normal normal 30px/39px Roboto;
letter-spacing: 0px;
color: #1D2121;

}

.timeline-p {
    /* font-weight: 100 !important; */
    font: normal normal normal 18px/27px Roboto;
    color: var(--dark);
}

.icon-cont {
    /* background: transparent url(img/Rectangle 615.png) 0% 0% no-repeat padding-box; */
    box-shadow: 0px 3px 6px #00000029;
    border-radius: 24px;
    padding: 10px;
    margin-right: 10%;
    margin-left: 10%;
    background: #f0f0f0;
}

.position {
 
box-shadow: 0px 3px 6px #00000029;
border-radius: 24px;
}

.open {
  background: #5433FF 0% 0% no-repeat padding-box;
  letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
text-align: center;
font: normal normal normal 14px/16px Roboto;
letter-spacing: 0px;
color: #FFFFFF;
padding: 3px;
width: 100px;
}

.filled {
  background: #636363 0% 0% no-repeat padding-box;
  letter-spacing: var(--unnamed-character-spacing-0);
color: var(--unnamed-color-ffffff);
text-align: center;
font: normal normal normal 14px/16px Roboto;
letter-spacing: 0px;
color: #FFFFFF;
padding: 3px;
width: 150px;
}

.pos_box {
    padding: 10px;
    /* background: #000; */
}

.marb_50 {
  margin-bottom: 50px;
}

.hero_form {
    box-shadow: 9px 9px 4px #0000004f;
    /* border-radius: 0px 100px 0px 144px; */
    background: #fff;
    width: 80%;
    margin-left: auto;
    margin-right: auto;
    padding: 20px;
    min-height: 400px;
}

.hero_form label {
  display:none;
}

.inputbox {
    background: var(--unnamed-color-ffffff) 0% 0% no-repeat padding-box;
    border: 1px solid var(--unnamed-color-ededf2);
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 2px 5px #26334d29;
    border: 1px solid #EDEDF2;
    border-radius: 5px;
    margin-bottom: 15px;
    width: 90%;
    margin-left: auto;
    margin-right: auto;
}

.inputcheck {
    background: var(--unnamed-color-ffffff) 0% 0% no-repeat padding-box;
    border: 1px solid var(--unnamed-color-ededf2);
    background: #FFFFFF 0% 0% no-repeat padding-box !important;
    box-shadow: 0px 2px 5px #26334d29 !important;
    border: 1px solid #EDEDF2 !important;
    border-radius: 5px !important;
    width: 25px;
    height: 20px !important;
    float: left;
    margin-bottom: 20px;
    text-align: left;

    margin-left: 100px;
    margin-right: 10px;
}

.inputtext {
    background: var(--unnamed-color-ffffff) 0% 0% no-repeat padding-box;
    border: 1px solid var(--unnamed-color-ededf2);
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 2px 5px #26334d29;
    border: 1px solid #EDEDF2;
    border-radius: 5px;
    margin-bottom: 15px;
    width: 90%;
    margin-top: 20px;
    margin-left: auto;
    margin-right: auto;
}

.hero_sub {
  background: var(--unnamed-color-5433ff) 0% 0% no-repeat padding-box;
background: #5433FF 0% 0% no-repeat padding-box;
box-shadow: 0px 3px 6px #00000029;
border-radius: 4px;
width: 90%;
margin-left: auto;
    margin-right: auto;
}

      </style>

<style>
            .accordion-content {
                max-width: 100%;
                margin: 0 auto;
                padding: 2rem;
                background: #fff;
                box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.09);
                border-radius: 8px;
            }

            .accordion-item {
                display: flex;
                flex-direction: column;
                padding: 0 1rem;
                border-radius: 5px;
                border: 1px solid #ddd;
                box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.09);
                cursor: pointer;
                background: #fff;
                margin-bottom: 0.5em;
            }

            .item-header {
                display: flex;
                justify-content: space-between;
                column-gap: 0.2em;
                padding: 10px;

            }

            .item-icon {
               
                flex: 0 0 25px;
                display: grid;
                place-items: center;
                font-size: 1.25rem;
                height: 25px;
                width: 25px;
                border-radius: 4px;
                background: #dedede;
                cursor: pointer;
                box-shadow: 0px 4px 16px rgba(0, 0, 0, 0.09);
            }

            .item-icon i {
                transition: all 0.25s cubic-bezier(0.5, 0, 0.1, 1);
            }

            .item-question {
                font-size: 1em;
                line-height: 1;
                font-weight: 500;
            }

            .active .item-icon i {
                transform: rotate(180deg);
            }

            .active .item-question {
                font-weight: 500;
            }

            .item-content {
                max-height: 0;
                overflow: hidden;
                transition: all 300ms ease;
            }

            .item-answer {
                line-height: 150%;
                opacity: 0.8;
            }


            h1,h2,h3 {

font-family: 'Poppins', sans-serif !important;

}

::placeholder {
    color: #958888 !important;
}

input,select,textarea {
    color: #958888!important;
}

.form-control{
    color: #958888 !important;
}

.center-text {
    text-align: center !important;
}

.top-banner {
padding-top: 70px;
}


@media  screen and (max-width:800px) {
    .top-banner {
padding-top: 50px;
}

.container {
    padding:10px;
}

.hero_form {
    margin-top: 20px;
    width: 100% !important;
}

.item-header {
    padding: 10px 0px;
}

.item-question {
    font-size: 14px;

}

.item-answer {
    text-align: left;
    font-size: 13px;
}

.accordion-content {
    padding: 10px;
    text-align: left;
}



.accordion-content {

    padding: 10px;

}

.hero_title {

    font: normal normal bold 30px/37px Urbane Rounded;
}

.banner-img {
    width: 100% !important;
}

.card-box {
    margin-bottom: 20px;
}

}

.bottop-cont h1 {
    text-align: left !important;
}


.bottop-cont h3 {
    text-align: left !important;
}

.accordion-item {
    margin-top: 30px;
}

.bottop-cont h2 {
    text-align: left !important;
    /* font-weight: 100 !important; */
    color: #403e3e;
    font-size: 28px;
}



.ftco-section {
    padding: 0px;
}

.hero_desc {

    margin-top: 20px;
}

h3.timeline-title {
    text-align: left;

}

.section_title {

    font: normal normal normal 30px/39px Roboto;
    text-align: left;
}
.timeline-p {
 
    text-align: justify;
}

.timeline-p.bottop-cont {
    padding-bottom: 40px;
}



#customers-testimonials12 .item-details12 p {
    font-size: 14px;
    font-style: italic;
}


.item-question {

    text-align: left;
}

.item-answer {
    text-align: left;
}

.bottop-cont ul li:before {
    width: 20px;
    height: 30px;
    margin-right: 10px;
    vertical-align: middle;
    /* background: url(https://hub.slikk.ai/assets/img/disc.png) no-repeat left center; */
    background-size: contain;
    content: '';
}

.bottop-cont ul li {
    list-style: disc;
    margin-bottom: 10px;
  
   
    font: normal normal normal 18px/27px Roboto;
}



.cat-menu {
    margin-bottom: 30px;
    /* background: #6B52F9 0% 0% no-repeat padding-box; */
    background: #6B52F9 0% 0% no-repeat padding-box;
    box-shadow: 0px 3px 6px #00000029;
    border-radius: 48px;
    padding: 10px 50px;
    color: #fff;
    width: calc(100% - 20px) !important;
    text-align: center;
  
  
    margin-left: 5px;
}


.cat-menu a {
    font-size: 15px;
}


.video-cont span {
    color: #fff;
    font-size: 32px;
    text-align: center;
}

.video-cont {
    background: #7E69F9;
    padding: 70px;
    margin-bottom: 10px;
    border-radius: 70px;
}

.video-cont span i{
text-align: center;
    margin: auto;
    display: block;
    margin-bottom: 20px;
    font-size: 47px;
}

.vid-cont {
    width: 100%;
    display: contents;
}

.video-box {
    border: 1px solid #d9d5d5;
    padding: 40px;
    /* border-radius: 70px; */
    /* background: var(--unnamed-color-ffffff) 0% 0% no-repeat padding-box; */
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 3px 6px #00000029;
    border-radius: 32px;
}

.outside-head {
    padding: 10px;
    text-align: center;
}

.post-block {

    margin-bottom: 20px;
}

.blog-cont {
    margin-right: 10px;
    margin-left: 10px;
    border-radius: 0px;
    background: #fff;
    margin-bottom: 20px;
}


        </style>

        <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W24QW8T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
</body>	<style>
    /* #Resets
–––––––––––––––––––––––––––––––––––––––––––––––––– */




/* #Universal and Default Styles
–––––––––––––––––––––––––––––––––––––––––––––––––– */
body {


  	font-family: "Open Sans", sans-serif !important;

}
a {text-decoration: none;}


.ul-reset {
	padding-left: 0;
   margin-top: 0;
   margin-bottom: 0;
	list-style: none;
}



/* #Navigation Styles
–––––––––––––––––––––––––––––––––––––––––––––––––– */
nav {
    background: #14008A;
    font-size: 0;
    position: fixed;
    width: 100%;
    z-index: 999;
}
nav > ul > li {
	display: inline-block;
  	font-size: 14px;
  	padding: 0 15px;
  	position: relative;
}
nav > ul > li:first-child {padding-left: 0;}
nav > ul > li:last-child {padding-right: 0;}
nav > ul > li > a {
	color: #fff;
  	display: block;
  	position: relative;
  	padding: 20px 0;

}
nav > ul > li:hover > a {
	color: #69aae0; 
  
}



/* #Mega Menu Styles
–––––––––––––––––––––––––––––––––––––––––––––––––– */
.mega-menu {
	background: transparent;
  	display: none;
  	left: 0;
  	position: absolute;
  	text-align: left;
  	width: 100%;
  	    z-index: 1000;

}
.mega-menu h3 {color: #fff;}
.mega-menu ul {
	float: left;
  	margin-bottom: 20px;
  	margin-right: 40px;
  	width: 205px;
}
.mega-menu ul:last-child {margin-right: 0;}
.mega-menu a {
	border-bottom: 1px solid #ddd;
  	color: #4ea3d8;
  	display: block;
  	padding: 10px 0;
}
.mega-menu a:hover {color: #2d6a91;}



/* #Droppable Class Styles
–––––––––––––––––––––––––––––––––––––––––––––––––– */
.droppable {position: static;}
.droppable > a:after {
	content: "\f107";
  	font-family: FontAwesome;
  	font-size: 12px;
  	padding-left: 6px;
  	position: relative;
  	top: -1px;
}
.droppable:hover .mega-menu {display: block;}



/* #Browser Clearfix
–––––––––––––––––––––––––––––––––––––––––––––––––– */
.cf:before,
.cf:after {
	content: " "; /* 1 */
   display: table; /* 2 */
}
.cf:after {clear: both;}

nav > ul > li {
    display: inline-block;
    font-size: 14px;
    padding: 0 25px;
    position: relative;
    font-size: 15px;
}

.mega-menu ul {
    float: left;
    
    /* margin-right: 40px; */
    width: 20%;
    padding: 20px;
    /* text-align: center; */
}

.mega-menu a {
    border-bottom: none;
    color: #fff;
    display: block;
    padding: 15px 0;
}
.features {
    width: 50%;
    display: block;
    float: left;
        box-shadow: 0px 3px 6px #00000029;
           
}

.features ul {
    width: 40%;
}

.container.cf {
    max-width: 70%;
    margin-left: auto;
    margin-right: auto;
    padding: 0px !important;
    background: #352689;
}

.mega-menu h3 {
    color: #fff;
    box-shadow: 0px 3px 6px #00000029;
    padding: 20px;
}

@media  screen and (max-width:800px){

  .desk-show {display:none;}
  .mob-show {display:block !important;}


  .home-banner {
    background: #552df6 url(img/Group914.png) 0% 0% no-repeat !important;
    opacity: 1 !important;
    background-size: cover; 
     background-position: cover;

    padding: 10px !important;;

    width: 100%;
  }
}



/* Important stuff here! Look at the bottom!!! (Line 133 to 136) */
*,
*::after,
*::before {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
 
}

:root {
  --nav-bg: #5433ff;
  --main-clr: #14008A;
  --nav-shadow: 0px 3px var(--main-clr);
}

.nav-mob {
  display: flex;
  align-items: center;
  justify-content: space-around;
  position: fixed;
  width: 100%;
  background: #5433ff;
  box-shadow: var(--nav-shadow);
  z-index: 999;
}

.nav-mob .logo {
  color: #fff;
  text-decoration-color: var(--main-clr);
  font-size: 22px;
  font-family: "Playfair Display", serif;
  font-weight: 100;0px 3px var(--main-clr)
}

.nav-mob ul {
  --padding: 20px;
  --font-size: 17px;
background:#14008A !important;
  list-style: none;
  display: flex;
  align-items: center;
  font-size: var(--font-size);
  overflow-y: hidden;
  transition: 1s cubic-bezier(.68,-0.55,.27,10.55);
  box-shadow: var(--nav-shadow);
}

.nav-mob ul li {
  padding: var(--padding);
}

.nav-mob ul li a {
  color: #fff;
  text-decoration: none;
  position: relative;
}

.nav-mob ul li a::after {
  content: "";
  width: 0%;
  height: 1.7px;
  border-radius: 99px;
  background: var(--main-clr);
  position: absolute;
  bottom: 0;
  left: 0;
  transition: 0.3s ease;
}

.nav-mob ul li a:hover::after {
  width: 100%;
}

.nav-mob .menu {
  width: 22px;
  height: 16px;
  cursor: pointer;
  display: none;
  align-items: center;
  flex-direction: column;
  justify-content: space-between;
  position: relative;
  margin: 20px;
}

.nav-mob .menu span {
  width: 100%;
  height: 2px;
  border-radius: 99px;
  background: #fff;
  transition: 0.3s ease;
  transform-origin: left;
}

.nav-mob .menu.active span {
  background: var(--main-clr);
}

nav .menu.active span:nth-child(1) {
  transform: rotate(40deg);
}
.nav-mob .menu span:nth-child(3) {
  transform-origin: left;
}

.nav-mob .menu.active span:nth-child(3) {
  transform: rotate(-40deg);
}

.nav-mob .menu.active span:nth-child(2) {
  transform: scale(0);
}

@media (max-width: 910px) {

  .nav-mob {
  display: flex !important;
  }
  .nav-mob .menu {
    display: flex;
  }



  .nav-mob ul {
    --height: 0px;

    flex-direction: column;
    background: var(--nav-bg);
    position: absolute;
    width: 100%;
    left: 0;
    top: 56px;
    height: var(--height);
    transition: 1s cubic-bezier(.68,-0.55,.27,1.55);
  }
  .nav-mob ul.active {
    --height: calc(
      (((var(--padding) * 2) + (var(--font-size) * 1.5))) * var(--childenNumber)
    );
    /*   (Block Level Padding + The Font Size) * The Number of Children   */
    
    
    transition: 1s ease;
  }

  .nav-mob ul li {
    width: 100%;
    text-align: center;
  }
  .nav-mob ul li a {
    width: 100%;
    text-transform: capitalize;
  }
}


ul.container.ul-reset {
    width: 50%;
    /* float: left; */
    display: inline-block;
    text-align: left;
    padding-left: 15%;
}

nav > ul > li > a:hover {
    color: #ffbb00 !important;
    text-decoration: none;
}

.mega-menu a:hover {
    color: #ffbb00 !important;
    text-decoration: none;
}

.features button {
border:none !important;
}

.book {
  background: #5433FF;
      padding: 6px 12px;
      border-radius: 5px;
      color:#fff;
}

.book:hover {
  background: hsl(250, 70%, 51%);
  
      color:#fff !important;
}


</style>
<script src="https://use.fontawesome.com/50e4eff350.js"></script>
<nav class="desk-show">
  <ul class="container ul-reset">
    <li style="width:130px"><a href='https://hub.slikk.ai/'><img src="https://hub.slikk.ai/img/Slikk-Logo-Blue.svg" style="width: 100%;"></a></li>
    <li class='droppable'>
      <a href='#'>Learn</a>
      <div class='mega-menu'>
      	<div class="container cf" style="max-width: 60%;">
          <ul class="ul-reset">
          
            <!--<li><a href='#'>Onboarding</a></li>-->
            <!--<li><a href='#'>Hierarchy</a></li>-->
            <li><a href='https://hub.slikk.ai/blog'>Blog</a></li>
            
          </ul><!-- .ul-reset -->
          <ul class="ul-reset">
          
            <!-- <li><a href='https://hub.slikk.ai/videos'>Videos</a></li> -->
            
            <li><a href="https://hub.slikk.ai/learn/video">Video</a></li>
            <!--<li><a href='https://hub.slikk.ai/book-a-demo'>On Demand Demo</a></li>-->
            
          </ul><!-- .ul-reset -->
          <ul class="ul-reset">
    
            <li><a href="https://hub.slikk.ai/learn/help">Help</a></li>
           
          </ul><!-- .ul-reset -->
          
           <!-- <ul class="ul-reset">
             <li><a href="https://hub.slikk.ai/learn/Support-Articles">Support Articles</a></li>
           
          </ul>-->
         
        </div><!-- .container -->
      </div><!-- .mega-menu -->
    </li><!-- .droppable -->
    <li class='droppable'>
      <a href='javascript:void(0)'>Product</a>
      <div class='mega-menu'>
        <div class="container cf">
            <div class="features">
                <h3>Features</h3>
              <ul class="ul-reset">
                
                <li><a href='https://hub.slikk.ai/features/360-degree-visibility'>360° Visibility</a></li>
                <li><a href='https://hub.slikk.ai/features/time-management'>Time Management</a></li>
                <li><a href='https://hub.slikk.ai/features/task-management'>Task Management</a></li>
                <li><a href='https://hub.slikk.ai/features/goal-management'>Goal Management</a></li>
                <li><a href='https://hub.slikk.ai/features/kanban-boards'>Kanban Boards</a></li>
                <li><a href='https://hub.slikk.ai/features/gantt-charts'>Gantt Charts</a></li>
              </ul><!-- .ul-reset -->
              <ul class="ul-reset">
              <li><a href='https://hub.slikk.ai/features/file-sharing'>File Sharing</a></li>
                <li><a href='https://hub.slikk.ai/features/reporting-and-analytics'>Reporting & Analytics</a></li>
                <li><a href='https://hub.slikk.ai/features/nudge-cards'>Nudge Cards</a></li>
                <li><a href='https://hub.slikk.ai/features/schedule-meeting'>Schedule Meeting</a></li>
                <li><a href='https://hub.slikk.ai/features/import'>Import</a></li>
                  <li><a href='https://hub.slikk.ai/features/docs'>Docs</a></li>
              </ul><!-- .ul-reset -->

            <button type="button" class="btn btn-primary btn-sm" style="background: #5433FF;color: #fff;margin: auto;width: 60%;margin-bottom: 10px;display: block;"><a href="https://hub.slikk.ai/features" style="padding:0px">View All</a></button>
          </div>
            <div class="features">
                <h3>Use Cases</h3>
              <ul class="ul-reset">
                
                <li><a href='https://hub.slikk.ai/use-case/project-management'>Project Management</a></li>
                <li><a href='https://hub.slikk.ai/use-case/software-development'>Software Development</a></li>
                <li><a href='https://hub.slikk.ai/use-case/sales'>Sales</a></li>
                <li><a href='https://hub.slikk.ai/use-case/startup'>Startup</a></li>
                <li><a></a></li>
                <div style="margin-bottom:3.2rem;"></div>
              </ul><!-- .ul-reset -->
              <ul class="ul-reset">
              
                <li><a href='https://hub.slikk.ai/use-case/remote-work'>Remote Work</a></li>
                <li><a href='https://hub.slikk.ai/use-case/marketing'>Marketing</a></li>
                <li><a href='https://hub.slikk.ai/use-case/designg'>Design</a></li>
                <li><a href='https://hub.slikk.ai/use-case/hr'>HR</a></li>
                <li><a></a></li>
                <div style="margin-bottom:3.2rem;"></div>
              </ul><!-- .ul-reset -->

            <button type="button" class="btn btn-primary btn-sm" style="background: #5433FF;color: #fff;margin: auto;width: 60%;margin-bottom: 10px;display: block;"><a href="https://hub.slikk.ai/use-cases" style="padding:0px">View All</a></button>
          </div><!-- cases -->
        </div><!-- .container -->
      </div><!-- .mega-menu-->
    </li><!-- .droppable -->

    <li><a href='https://hub.slikk.ai/pricing'>Pricing</a></li>

  </ul><!-- .container .ul-reset -->
  <ul class="container ul-reset" style="text-align: right;
  display: inline-block;
  padding-right: 15%;
  padding-left: 0;">

    <li><a href='https://hub.slikk.ai/join-us'>Sign In</a></li>
    <li><a href='https://hub.slikk.ai/book-a-demo' class='book'>Book A Demo</a></li>
  </ul><!-- .container .ul-reset -->
</nav>



<style>

.navigation {
    height: 60px;
    background: #14008A;
    position: fixed;
    top: 0;
    z-index: 1000;
    width: 100%;
}
 .brand {

	 padding-left: 20px;
	 float: left;
	 line-height: 60px;
	 text-transform: uppercase;
	 font-size: 1.4em;
}
 .brand a, .brand a:visited {
	 color: #fff;
	 text-decoration: none;
}
 .nav-container {
	 max-width: 100%;
	 margin: 0 auto;
   display: inline-block;
   width: 100%;
}
 #nav2 {
	 float: right;
   z-index: 10;
}
#nav2 ul {
	 list-style: none;
	 margin: 0;
	 padding: 0;
  padding-bottom: 20px;
  background:#14008A;
  margin-top:58px;

    overflow-y: scroll;
    height: 100vh;

}
ul.nav-dropdown h3 {
  
    font-size: 19px;
    padding: 10px;
    color: yellow !important;
}

ul.nav-dropdown h3 a {
    color: #fff;
    font-size: 19px;
    padding: 10px;
    color: yellow !important;
}

#nav2 ul li {
	 float: left;
	 position: relative;
   padding: 0px !important;
   text-align: center;
}
#nav2 ul li a, #nav2 ul li a:visited {
	 display: block;
	 padding: 0 20px;
	 line-height: 70px;
	 background: #14008A;
	 color: #fff;
	 text-decoration: none;
}
#nav2 ul li a:hover, #nav2 ul li a:visited:hover {
	 background: #2581dc;
	 color: #fff;
}
#nav2 ul li a:not(:only-child):after, #nav2 ul li a:visited:not(:only-child):after {
	 padding-left: 4px;
	 content: ' ▾';
}

#nav2 ul li ul {
  overflow-y: scroll;
    height: 100vh;
}

#nav2 ul li ul li {
	 min-width: 190px;
}

#nav2 ul li ul li a {
	 padding: 15px;
	 line-height: 20px;
}
 .nav-dropdown {
	 position: absolute;
	 display: none;
	 z-index: 1;
	 box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);
}
/* Mobile navigation */
.nav-mobile {
    display: none;
    position: fixed;
    top: 0;
    right: 20px;
    background: #14008A;
  
    width: 70px;
}
 @media  only screen and (max-width: 798px) {
	 .nav-mobile {
		 display: block;
	}
  #nav2 {
		 
		 /* padding: 70px 0 15px; */
	}
  #nav2 ul {
		 display: none;
	}
  #nav2 ul li {
		 float: none;
     width:100%;
     background: #14008A;
	}

  
  #nav2 ul li a {
		 padding: 15px;
		 line-height: 20px;
	}
  #nav2 ul li ul li a {
		 padding-left: 30px;
	}
	 .nav-dropdown {
		 position: static;
	}
}
 @media  screen and (min-width: 799px) {
	 .nav-list {
		 display: block !important;
	}
}
 #nav-toggle {
	 position: absolute;
	 left: 18px;
	 top: 18px;
	 cursor: pointer;
	 padding: 10px 35px 16px 0px;
}
 #nav-toggle span, #nav-toggle span:before, #nav-toggle span:after {
	 cursor: pointer;
	 border-radius: 1px;
	 height: 3px;
	 width: 27px;
	 background: #fff;
	 position: absolute;
	 display: block;
	 content: '';
	 transition: all 300ms ease-in-out;
}
 #nav-toggle span:before {
	 top: -10px;
}
 #nav-toggle span:after {
	 bottom: -10px;
}
 #nav-toggle.active span {
	 background-color: transparent;
}
 #nav-toggle.active span:before, #nav-toggle.active span:after {
	 top: 0;
}
 #nav-toggle.active span:before {
	 transform: rotate(45deg);
}
 #nav-toggle.active span:after {
	 transform: rotate(-45deg);
}
 

.brand a img {
    width: 60%;
}
</style>

<section class="navigation mob-show" style="display:none;">
  <div class="nav-container">
    <div class="brand">
      <a href='https://hub.slikk.ai/'><img src="https://hub.slikk.ai/img/Slikk-Logo-Blue-mobile.png"></a>
    </div>
    <nav id="nav2">
      <div class="nav-mobile"><a id="nav-toggle" href="#!"><span></span></a></div>
      <ul class="nav-list">
     
        <li>
          <a href="#!">Learn</a>
          <ul class="nav-dropdown">
            <li><a href='#'>Onboarding</a></li>
            <li><a href='#'>Hierarchy</a></li>
            <li><a href='https://hub.slikk.ai/blog'>Blog</a></li>

            <li><a href='#'>Videos</a></li>
            <li><a href='https://hub.slikk.ai/book-a-demo'>On Demand Demo</a></li>

            <li><a href="https://hub.slikk.ai/learn/help-new">Help</a></li>
            <!-- <li><a href="https://hub.slikk.ai/learn/Support-Articles">Support Articles</a></li> -->
          </ul>
        </li>

        <li>
          <a href="#!">Product</a>
          
          <ul class="nav-dropdown">
            <h3><a href="https://hub.slikk.ai/features">Features</a></h3>
            <li><a href='https://hub.slikk.ai/features/360-degree-visibility'>360° Visibility</a></li>
            <li><a href='https://hub.slikk.ai/features/time-management'>Time Management</a></li>
            <li><a href='https://hub.slikk.ai/features/task-management'>Task Management</a></li>
            <li><a href='https://hub.slikk.ai/features/goal-management'>Goal Management</a></li>
            <li><a href='https://hub.slikk.ai/features/kanban-boards'>Kanban Boards</a></li>
             <li><a href='https://hub.slikk.ai/features/gantt-charts'>Gantt Charts</a></li>
             <li><a href='https://hub.slikk.ai/features/file-sharing'>File Sharing</a></li>
         
           
            <li><a href='https://hub.slikk.ai/features/reporting-and-analytics'>Reporting & Analytics</a></li>
            <li><a href='https://hub.slikk.ai/features/nudge-cards'>Nudge Cards</a></li>
            <li><a href='https://hub.slikk.ai/features/schedule-meeting'>Schedule Meeting</a></li>
             <li><a href='https://hub.slikk.ai/features/import'>Import</a></li>
              <li><a href='https://hub.slikk.ai/features/docs'>Docs</a></li>
         

                 <li><a href='https://hub.slikk.ai/features' class='book'>View All Features</a></li>

                 <h3><a href="https://hub.slikk.ai/use-cases">Use Cases</a></h3>
                 <li><a href='https://hub.slikk.ai/use-case/project-management'>Project Management</a></li>
                 <li><a href='https://hub.slikk.ai/use-case/software-development'>Software Development</a></li>
                 <li><a href='https://hub.slikk.ai/use-case/sales'>Sales</a></li>
                 <!-- <li><a href='#'>CRM</a></li> -->
                 <li><a href='https://hub.slikk.ai/use-case/startup'>Startup</a></li>
                 <li><a href='https://hub.slikk.ai/use-case/remote-work'>Remote Work</a></li>
                 <li><a href='https://hub.slikk.ai/use-case/marketing'>Marketing</a></li>
                 <!-- <li><a href='#'>Non Profit</a></li> -->
                 <li><a href='https://hub.slikk.ai/use-case/design'>Design</a></li>
                 <li><a href='https://hub.slikk.ai/use-case/hr'>HR</a></li>
                 <!-- <li><a href='#'>Events</a></li> -->

                 <li><a href='https://hub.slikk.ai/use-cases' class='book'>View All Cases</a></li>
          </ul>
        </li>

        
        <li><a href='https://hub.slikk.ai/pricing'>Pricing</a></li>

   
        <li><a href='https://hub.slikk.ai/join-us'>Sign In</a></li>
        <li><a href='https://hub.slikk.ai/book-a-demo' class='book'>Book a Demo</a></li>

        
       
      </ul>
    </nav>
  </div>
</section>


<!-- Just a simple layout -->



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<script>


(function($) { // Begin jQuery
  $(function() { // DOM ready
    // If a link has a dropdown, add sub menu toggle.
    $('nav ul li a:not(:only-child)').click(function(e) {
      $(this).siblings('.nav-dropdown').toggle();
      // Close one dropdown when selecting another
      $('.nav-dropdown').not($(this).siblings()).hide();
      e.stopPropagation();
    });
    // Clicking away from dropdown will remove the dropdown class
    $('html').click(function() {
      $('.nav-dropdown').hide();
    });
    // Toggle open and close nav styles on click
    $('#nav-toggle').click(function() {
      $('nav ul').slideToggle();
    });
    // Hamburger to X toggle
    $('#nav-toggle').on('click', function() {
      this.classList.toggle('active');
    });
  }); // end DOM ready
})(jQuery); // end jQuery

  // For toggling and finding number of children and other stuff is done here!

// const navigation = document.getElementById("nav");
// const menu = document.getElementById("menu");

// menu.addEventListener("click", () => {
//   // The navigation.children.length means the following :-
//   // The children inside a parent are basically an array of elements; So, here I'm finding the length of the array aka how many children are inside the nav bar.
//   //   Yup That's all.
//   navigation.style.setProperty("--childenNumber", navigation.children.length);

//   //    Casually Toggling Classes to make them animate on click
//   //   Regular stuff ;)
//   navigation.classList.toggle("active");
//   menu.classList.toggle("active");
// });

</script>	 
	
    <style>
        .highlights {
            width: 70%;
        }

        .left-high {
            color: yellow;
            width: 30%;
            float: left;

        }

        .right-high {
            color: #fff;
            text-align: left;
        }

        .banner-img {
            width: 80%;
        }

        @media  screen and (max-width:800px) {
            .banner-img {
                display: none;
            }

        }

        .hero_desc {
            font: var(--unnamed-font-style-normal) normal var(--unnamed-font-weight-normal) var(--unnamed-font-size-25)/var(--unnamed-line-spacing-33) var(--unnamed-font-family-roboto);
            letter-spacing: var(--unnamed-character-spacing-0);
            color: var(--unnamed-color-ffffff);
            text-align: left;
            font: normal normal normal 18px/23px Roboto;
            letter-spacing: 0px;
            color: #FFFFFF;
            padding-top: 30px !important;
            opacity: 1;
            padding-bottom: 30px;
        }

        .banner_button:hover {
            box-shadow: 0px 0px 5px 2px #a7a192;
        }

        .banner_button2:hover {
            box-shadow: 0px 0px 5px 2px #a7a192;
        }
		.highlight-box{
			margin: 0 auto;
			padding: 2rem;
			background: #fff;
			box-shadow: 0px 4px 16px rgb(0 0 0 / 9%);
			border-radius: 8px;
			margin-bottom:20px;
		}
        .zoom {
			transition: transform .2s;
			margin: 0 auto;
			position: relative;
			z-index: 1;
		}
		.zoom:hover {
		  transform: scale(1.1);
		}
		.wid100 {
			width:100%;
		}
		.pad20 {
			padding: 20px;
		}
    </style>
		
	<div class="jumbotron text-center home-banner top-banner" style="background: transparent url(https://hub.slikk.ai/assets/page/time-manage.png) 0% 0% no-repeat;
                opacity: 1;
                background-size: cover;
                background-position: bottom;    min-height: 400px;    padding-bottom: 30px;">
        <div class="container">
            <div class="row" style="padding-top: 7%;">
                <div class="col-sm-5 pad20" style="text-align:left">
                    <h1 class="hero_title">Detailed Insights With 360 Degree Visibility</h1>
                     								<p class="hero_desc"><span style="font-weight: 400;">For years, our teams have been split - juggling between spreadsheets, docs and emails. Slikk’s actionable insights bring us back together. Everything you need to make decisions faster.</span></p>

                    <br>
                    <br>

                    
                </div>

                <div class="col-sm-7">
									 <img src="https://hub.slikk.ai/assets/page/Birds Eye View-Hero Image@2x.png" class="img-responsive banner-img zoom wid100 zoom"/>
								
                   
                </div>

            </div>

        </div>

    </div>
<div class="container">
<style>
   .timeline-p li:before {
    display: block;
    flex-shrink: 0;
    width: 33px;
    height: 33px;
    margin-right: 10px;

    vertical-align: middle;

    background: url('https://hub.slikk.ai/assets/img/li.png') no-repeat left center;
    background-size: contain;

    content: '';
}

.timeline-p li {
    list-style: none;
    display: flex;
    margin-bottom:20px;
    font-size: 14px;
}
.mtr-3{
    margin-top: 3rem;
}
</style>
<div class="row marb_50" style="background: #FDF6FF 0% 0% no-repeat padding-box;">

        <div class="col-sm-7 timeline-right text-center">
            				 <img src="https://hub.slikk.ai/assets/page/360 1.png" class="zoom mtr-3" style="width:100%;height:auto;">
									
								           

        </div>

        <div class="col-sm-5 timeline-left  d-flex align-items-center pad20">
            <div class="timeline-cont">
                <h3 class="timeline-title" style="text-align:left;padding-bottom:0px">Get Detailed Visuals With 360 Degree Visibility</h3>
                <b class="sub_all">
				 								
				</b>

                <ul class="timeline-p" style="margin-top: 20px;">
					                    <li>Relevant insights and best practices show you what&#039;s working, where you can improve, and who is doing what.</li>
					                    <li>Get the most detailed view of your team&#039;s performance at work with easy-to-understand visuals.</li>
					                    <li>Coordinate with stakeholders, leave feedback, and keep everyone informed, all together in Slikk.</li>
					                    <li>Know your team’s current and next steps with this 360 degree visibility.</li>
					                    <li>It helps you to look out for any potential risk to get it resolved beforehand.</li>
					                </ul>

            </div>
        </div>


    </div>
    </div>
												
						<div style="background: #FFF 0% 0% no-repeat padding-box;padding-top: 30px">
<div class="container">
<style>
   .timeline-p li:before {
    display: block;
    flex-shrink: 0;
    width: 33px;
    height: 33px;
    margin-right: 10px;

    vertical-align: middle;

    background: url('https://hub.slikk.ai/assets/img/li.png') no-repeat left center;
    background-size: contain;

    content: '';
}

.timeline-p li {
    list-style: none;
    display: flex;
    margin-bottom:20px;
    font-size: 14px;
}
</style>
 <div class="row marb_50">
        <div class="col-sm-5 timeline-left  d-flex align-items-center order-12 order-md-1 pad20">
            <div class="timeline-cont">
                <h3 class="timeline-title" style="text-align:left;padding-bottom:0px">360 Degree Visibility: View That Notices Minute Details</h3>
                <b class="sub_all">
				 								
				
				</b>

                <ul class="timeline-p" style="margin-top: 20px;">
					                    <li>The 360 degree visibility lets you demonstrate results in the best way possible.</li>
                                        <li>Slikk‘s productivity tool provides the metrics your teams need to prove ROI.</li>
                                        <li>See a complete set of assignments to assess, prioritize, and group budget.</li>
                                        <li>Create and view portfolio assignments with Slikk’s 360 degree visibility feature.</li>
                                        <li>It effectively prioritizes tasks and makes greater choices to accomplish better results.</li>
                                    </ul>

            </div>
        </div>
        <div class="col-sm-7 timeline-right order-1 order-md-12">
		 				 <img src="https://hub.slikk.ai/assets/page/360 2.png" class="zoom" style="width:100%">
									
																
            

        </div>

    </div>
    </div>
    </div>													
							<div class="container">
<style>
   .timeline-p li:before {
    display: block;
    flex-shrink: 0;
    width: 33px;
    height: 33px;
    margin-right: 10px;

    vertical-align: middle;

    background: url('https://hub.slikk.ai/assets/img/li.png') no-repeat left center;
    background-size: contain;

    content: '';
}

.timeline-p li {
    list-style: none;
    display: flex;
    margin-bottom:20px;
    font-size: 14px;
}
.mtr-3{
    margin-top: 3rem;
}
</style>
<div class="row marb_50" style="background: #FDF6FF 0% 0% no-repeat padding-box;">

        <div class="col-sm-7 timeline-right text-center">
            				 <img src="https://hub.slikk.ai/assets/page/360 3.png" class="zoom mtr-3" style="width:100%;height:auto;">
									
								           

        </div>

        <div class="col-sm-5 timeline-left  d-flex align-items-center pad20">
            <div class="timeline-cont">
                <h3 class="timeline-title" style="text-align:left;padding-bottom:0px">A Clear Picture With 360 Degree Visibility</h3>
                <b class="sub_all">
				 								
				</b>

                <ul class="timeline-p" style="margin-top: 20px;">
					                    <li>The 360 degree visibility offers multiple views to get transparency on projects.</li>
					                    <li>Find and fix anything that lowers the productivity of your teams.</li>
					                    <li>Get graphs and charts to know workload distribution and task progress.</li>
					                    <li>Know your short-term and long-term operations and assign them accordingly.</li>
					                    <li>Get a superior view of your tasks to know the loopholes and the task completion date.</li>
					                </ul>

            </div>
        </div>


    </div>
    </div>
					    </div>
    

        <!------------------------------------ phone slider start ----------------------------------->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.1/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        

        <script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.1/owl.carousel.min.js"></script>

        

        <!------------------------------- Phone Slider close -------------------------------------------->
            <div class="container">

                                    <div class="row">
                        <div class="col-sm-12 bottom-cont" style="text-align:justify;margin-top:30px;">
                            <div class="timeline-cont">
                                <div class="timeline-p">

                                    <div class="accordion-content">
                                        <h2>FAQs</h2>


                                                                                    <div class="accordion-item">

                                                                                                    <header class="item-header">
                                                        <h3 class="item-question">
                                                            What can I gain from using 360 degree visibility feature?
                                                        </h3>
                                                        <div class="item-icon">
                                                            <i class='bx bx-chevron-down'></i>
                                                        </div>
                                                    </header>


                                                    <div class="item-content">
                                                        <p class="item-answer">
                                                            With this feature your tasks become much easier as you can visualize everything needed to complete your project. Slikk’s customizable dashboard let’s you choose exactly what you want, pin important to-dos, and follow up with the employees to keep a close eye on the progress.
                                                        </p>
                                                    </div>
                                            </div>
                                        
                                                                                    <div class="accordion-item">
                                                <header class="item-header">
                                                    <h3 class="item-question">
                                                        Is it easy to use this feature?
                                                    </h3>
                                                    <div class="item-icon">
                                                        <i class='bx bx-chevron-down'></i>
                                                    </div>
                                                </header>


                                                <div class="item-content">
                                                    <p class="item-answer">
                                                        Yes, it is extremely easy to use this feature. Slikk has a dedicated help center that has interactive training and videos to help you get started.
                                                    </p>
                                                </div>
                                            </div>
                                        
                                                                                    <div class="accordion-item">
                                                <header class="item-header">
                                                    <h3 class="item-question">
                                                        Will this feature save my time?
                                                    </h3>
                                                    <div class="item-icon">
                                                        <i class='bx bx-chevron-down'></i>
                                                    </div>
                                                </header>


                                                <div class="item-content">
                                                    <p class="item-answer">
                                                        Slikk’s 360 degree visibility offers unparalleled overview across departments at one go. You can find information quickly to make real time decisions. Thus, you save a good amount of time.
                                                    </p>
                                                </div>
                                            </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                                        
            </div>

        </div>
    </div>
    </div>
    
    <script>
        const accordionBtns = document.querySelectorAll(".item-header");

        accordionBtns.forEach((accordion) => {
            accordion.onclick = function() {
                this.classList.toggle("active");

                let content = this.nextElementSibling;
                console.log(content);

                if (content.style.maxHeight) {
                    //this is if the accordion is open
                    content.style.maxHeight = null;
                } else {
                    //if the accordion is currently closed
                    content.style.maxHeight = content.scrollHeight + "px";
                    console.log(content.style.maxHeight);
                }
            };
        });
    </script>

    </div>



    <div class="row">
        <div class="col-sm-12 bottom-cont" style="text-align:justify;margin-top:30px;">
            <div class="timeline-cont">
                <div class="timeline-p bottop-cont">

                                        <h2><strong>Slikk’s 360 degree Visibility Makes Everything Manageable</strong></h2>
<p><span>Just like the car drivers would constantly check the side mirrors and the rear-view mirrors while concentrating on the road, in the same way the managers too need to apply the same logic to ensure visibility at work. However, very few firms follow this method as it takes a lot of time and energy to keep track of everything. Slikk’s </span>360 degree visibility <span>makes it easy for you</span><strong>. </strong><span>With colorful and informative visuals, managers are sure to reach higher productivity every time, all the time!</span></p>
<h2><strong>Get Well-Defined Scope with Slikk’s 360 Degree Visibility</strong></h2>
<p><span>The most important objective of any firm to improve project management is a well-defined scope. The four objectives of any firm is-</span></p>
<ul>
<li><span>Proper and clear </span>Task Management<span> document control</span></li>
<li><span>Clear view of which projects are profitable</span></li>
<li><span>Better compliance process</span></li>
<li><span>Better management procedures</span></li>
</ul>
<p><span>All these are possible when you can view everything under one roof. This roof is offered by Slikk which ensures your project goes a long way.</span></p>
<h2><strong>Nurturing The Talented Employees with 360 Degree Visibility</strong></h2>
<p>360 Degree Visibility <span>lets the managers know the efforts of the employees. It manages the talented members and clearly shows how much effort is put in a particular task. The visibility ensures that a company can jostle above their competitors to continuously stay on the peak. </span>360 Degree Visibility <span>is easy to use and offers a clean view.</span></p>
<h2><strong>How Slikk’s 360 Degree Visibility Will Keep You At The Forefront?</strong></h2>
<p><span>The world no doubt has become competitive, and to always stay on the top everything needs to be managed the right way. The lack of visibility can keep you behind and will not let you win the race. Hence, it becomes imperative to have 360 Degree Visibility across the entire business. Visibility where nothing goes unnoticed! Try Slikk today to know how we make things easy for you.</span></p>

                </div>
            </div>
        </div>


    </div>

    </div>


    <!--
            <div class="row">



            <div class="col-sm-12 bottom-cont d-flex" style="text-align:justify;margin-top:30px;">
              <div class="timeline-cont">
                <div class="timeline-p">&lt;h2&gt;&lt;strong&gt;Slikk&amp;rsquo;s 360 degree Visibility Makes Everything Manageable&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Just like the car drivers would constantly check the side mirrors and the rear-view mirrors while concentrating on the road, in the same way the managers too need to apply the same logic to ensure visibility at work. However, very few firms follow this method as it takes a lot of time and energy to keep track of everything. Slikk&amp;rsquo;s &lt;/span&gt;360 degree visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;makes it easy for you&lt;/span&gt;&lt;strong&gt;. &lt;/strong&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;With colorful and informative visuals, managers are sure to reach higher productivity every time, all the time!&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;Get Well-Defined Scope with Slikk&amp;rsquo;s 360 Degree Visibility&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;The most important objective of any firm to improve project management is a well-defined scope. The four objectives of any firm is-&lt;/span&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Proper and clear &lt;/span&gt;Task Management&lt;span style=&quot;font-weight: 400;&quot;&gt; document control&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Clear view of which projects are profitable&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Better compliance process&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Better management procedures&lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;All these are possible when you can view everything under one roof. This roof is offered by Slikk which ensures your project goes a long way.&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;Nurturing The Talented Employees with 360 Degree Visibility&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;360 Degree Visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;lets the managers know the efforts of the employees. It manages the talented members and clearly shows how much effort is put in a particular task. The visibility ensures that a company can jostle above their competitors to continuously stay on the peak. &lt;/span&gt;360 Degree Visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;is easy to use and offers a clean view.&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;How Slikk&amp;rsquo;s 360 Degree Visibility Will Keep You At The Forefront?&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;The world no doubt has become competitive, and to always stay on the top everything needs to be managed the right way. The lack of visibility can keep you behind and will not let you win the race. Hence, it becomes imperative to have 360 Degree Visibility across the entire business. Visibility where nothing goes unnoticed! Try Slikk today to know how we make things easy for you.&lt;/span&gt;&lt;/p&gt;</div>
              </div>
            </div>


            </div>



              <div class="row">



            <div class="col-sm-12 bottom-cont d-flex" style="text-align:justify;margin-top:30px;">
              <div class="timeline-cont">
                <div class="timeline-p">&lt;h2&gt;&lt;strong&gt;Slikk&amp;rsquo;s 360 degree Visibility Makes Everything Manageable&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Just like the car drivers would constantly check the side mirrors and the rear-view mirrors while concentrating on the road, in the same way the managers too need to apply the same logic to ensure visibility at work. However, very few firms follow this method as it takes a lot of time and energy to keep track of everything. Slikk&amp;rsquo;s &lt;/span&gt;360 degree visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;makes it easy for you&lt;/span&gt;&lt;strong&gt;. &lt;/strong&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;With colorful and informative visuals, managers are sure to reach higher productivity every time, all the time!&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;Get Well-Defined Scope with Slikk&amp;rsquo;s 360 Degree Visibility&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;The most important objective of any firm to improve project management is a well-defined scope. The four objectives of any firm is-&lt;/span&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Proper and clear &lt;/span&gt;Task Management&lt;span style=&quot;font-weight: 400;&quot;&gt; document control&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Clear view of which projects are profitable&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Better compliance process&lt;/span&gt;&lt;/li&gt;
&lt;li style=&quot;font-weight: 400;&quot;&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;Better management procedures&lt;/span&gt;&lt;/li&gt;
&lt;/ul&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;All these are possible when you can view everything under one roof. This roof is offered by Slikk which ensures your project goes a long way.&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;Nurturing The Talented Employees with 360 Degree Visibility&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;360 Degree Visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;lets the managers know the efforts of the employees. It manages the talented members and clearly shows how much effort is put in a particular task. The visibility ensures that a company can jostle above their competitors to continuously stay on the peak. &lt;/span&gt;360 Degree Visibility &lt;span style=&quot;font-weight: 400;&quot;&gt;is easy to use and offers a clean view.&lt;/span&gt;&lt;/p&gt;
&lt;h2&gt;&lt;strong&gt;How Slikk&amp;rsquo;s 360 Degree Visibility Will Keep You At The Forefront?&lt;/strong&gt;&lt;/h2&gt;
&lt;p&gt;&lt;span style=&quot;font-weight: 400;&quot;&gt;The world no doubt has become competitive, and to always stay on the top everything needs to be managed the right way. The lack of visibility can keep you behind and will not let you win the race. Hence, it becomes imperative to have 360 Degree Visibility across the entire business. Visibility where nothing goes unnoticed! Try Slikk today to know how we make things easy for you.&lt;/span&gt;&lt;/p&gt;</div>
              </div>
            </div>


            </div> -->




    </div>
	<section class="ftco-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 text-center">

            </div>
        </div>
    </div>
</section>
<footer class="footer-02">
  <div class="container">
        

        <div class="col-md-12 col-lg-12">
            <div class="row">
                <div class="col-md-4 mb-md-0 mb-4">
                  <img src="https://hub.slikk.ai/img/Slikk-Logo-Blue-mobile.png" style="margin-bottom: 10px;">
                  <br>
                   <p>Slikk.ai helps you get more tasks done in less time. It's everything you need to work faster, collaborate better, and improve productivity at your workplace..</p>
                   <ul class="social-link">
                            <li><a href="https://www.facebook.com/slikkprojectmanagement" class="d-block" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                            <li><a href="https://twitter.com/Slikk_ai" class="d-block" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/slikk.ai/" class="d-block" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com/company/slikk-ai" class="d-block" target="_blank"><i class="bx bxl-linkedin"></i></a></li>
                            <li><a href="https://www.youtube.com/@Slikkai" class="d-block" target="_blank"><i class="bx bxl-youtube"></i></a></li></ul>
                    </ul>
                </div>
                <div class="col-md-4 mb-md-0 mb-4" style="text-align: center;">
                    <h2 class="footer-heading">About</h2>
                    <ul class="list-unstyled">
                        <li><a href="https://hub.slikk.ai/about-us" class="py-1 d-block">About Us</a></li>
                        <li><a href="https://hub.slikk.ai/features" class="py-1 d-block">Features</a></li>
                        <li><a href="https://hub.slikk.ai/use-cases" class="py-1 d-block">Use Cases</a></li>
                  
                        
                    </ul>
                </div>
                <div class="col-md-4 mb-md-0 mb-4" style="text-align: center;">
                    <h2 class="footer-heading">Resources</h2>
                    <ul class="list-unstyled">
                        <li><a href="https://hub.slikk.ai/book-a-demo" class="py-1 d-block">Book A Demo</a></li>
                        <li><a href="https://hub.slikk.ai/blog" class="py-1 d-block">Blog</a></li>
                        <li><a href="https://hub.slikk.ai/pricing" class="py-1 d-block">Pricing</a></li>
                       
                    </ul>
                </div>

               
               
            </div>

            <div class="row">
            <div class="col-md-6 mb-md-0 mb-4" style="text-align: left;color: #fff;margin-top: 20px;">
                <span>
                    <img src="https://hub.slikk.ai/assets/single/72.png" class="d-inline" style="width: 20px;">
                </span>
                connect@slikk.ai
            </div>

            <div class="col-md-6 mb-md-0 mb-4" style="text-align: right;">
                <ul class="d-inline-flex list-unstyled">
                    <li class="terms" style="padding:10px"><a href="https://hub.slikk.ai/terms">Terms</a></li>
                    <li class="terms" style="padding:10px"><a href="https://hub.slikk.ai/privacy-policy">Privacy</a></li>
                    <li class="terms" style="padding:10px"><a href="https://hub.slikk.ai/security">Security</a></li>
                </ul>
            </div>

        </div>
              
        </div>
    </div>

    </div>
</footer>

<style>
    body {}



    .col-1,
    .col-2,
    .col-3,
    .col-4,
    .col-5,
    .col-6,
    .col-7,
    .col-8,
    .col-9,
    .col-10,
    .col-11,
    .col-12,
    .col,
    .col-auto,
    .col-sm-1,
    .col-sm-2,
    .col-sm-3,
    .col-sm-4,
    .col-sm-5,
    .col-sm-6,
    .col-sm-7,
    .col-sm-8,
    .col-sm-9,
    .col-sm-10,
    .col-sm-11,
    .col-sm-12,
    .col-sm,
    .col-sm-auto,
    .col-md-1,
    .col-md-2,
    .col-md-3,
    .col-md-4,
    .col-md-5,
    .col-md-6,
    .col-md-7,
    .col-md-8,
    .col-md-9,
    .col-md-10,
    .col-md-11,
    .col-md-12,
    .col-md,
    .col-md-auto,
    .col-lg-1,
    .col-lg-2,
    .col-lg-3,
    .col-lg-4,
    .col-lg-5,
    .col-lg-6,
    .col-lg-7,
    .col-lg-8,
    .col-lg-9,
    .col-lg-10,
    .col-lg-11,
    .col-lg-12,
    .col-lg,
    .col-lg-auto,
    .col-xl-1,
    .col-xl-2,
    .col-xl-3,
    .col-xl-4,
    .col-xl-5,
    .col-xl-6,
    .col-xl-7,
    .col-xl-8,
    .col-xl-9,
    .col-xl-10,
    .col-xl-11,
    .col-xl-12,
    .col-xl,
    .col-xl-auto {
        position: relative;
        width: 100%;
        padding-right: 15px;
        padding-left: 15px;
    }

    .col {
        -ms-flex-preferred-size: 0;
        flex-basis: 0;
        -webkit-box-flex: 1;
        -ms-flex-positive: 1;
        flex-grow: 1;
        max-width: 100%;
    }

    .col-auto {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 auto;
        flex: 0 0 auto;
        width: auto;
        max-width: 100%;
    }

    .col-1 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 8.33333%;
        flex: 0 0 8.33333%;
        max-width: 8.33333%;
    }

    .col-2 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 16.66667%;
        flex: 0 0 16.66667%;
        max-width: 16.66667%;
    }

    .col-3 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 25%;
        flex: 0 0 25%;
        max-width: 25%;
    }

    .col-4 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 33.33333%;
        flex: 0 0 33.33333%;
        max-width: 33.33333%;
    }

    .col-5 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 41.66667%;
        flex: 0 0 41.66667%;
        max-width: 41.66667%;
    }

    .col-6 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
    }

    .col-7 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 58.33333%;
        flex: 0 0 58.33333%;
        max-width: 58.33333%;
    }

    .col-8 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 66.66667%;
        flex: 0 0 66.66667%;
        max-width: 66.66667%;
    }

    .col-9 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 75%;
        flex: 0 0 75%;
        max-width: 75%;
    }

    .col-10 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 83.33333%;
        flex: 0 0 83.33333%;
        max-width: 83.33333%;
    }

    .col-11 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 91.66667%;
        flex: 0 0 91.66667%;
        max-width: 91.66667%;
    }

    .col-12 {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }



    .form-control {
        height: 52px;
        background: #fff;
        color: #000;
        font-size: 18px;
        border-radius: 0px;
        -webkit-box-shadow: none;
        box-shadow: none;
        border: 1px solid rgba(0, 0, 0, 0.1);
    }

    .form-control:focus,
    .form-control:active {
        outline: none !important;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

    textarea.form-control {
        height: inherit !important;
    }

    .ftco-section {
    padding: 0px;
    background: #ffffff;
}

    .ftco-section h2 {
        margin-bottom: 0;
    }

    footer {
        padding: 20px;
        border-radius: 0px;
    }

    .footer-02 {
        background: #5433ff;
        padding-top: 50px;
    }

    .footer-02 .footer-heading {
        font-size: 19px;
        color: #fff;
        margin-bottom: 20px;
    }

    .footer-02 .footer-heading .logo {
        color: #fff;
        text-transform: uppercase;
    }

    .footer-02 a {
        color: #bba387;
    }

    .footer-02 p {
        color: #fff;
    }

    .footer-02 .copyright {
        color: rgba(255, 255, 255, 0.4);
        font-size: 14px;
    }

    .footer-02 .list-unstyled li a {
        color: #fff;
    }

    .footer-02 .list-unstyled li a:hover {
        color: #fff;
    }

    .footer-02 .list-unstyled a {
        color: #c4c4c4
    }

    .footer-02 .list-unstyled a:hover {
        color: #c4c4c4
       
       
    }

    .footer-02 .subscribe {
        margin-top: -105px;
    }

    .footer-02 .subscribe-form {
        border-radius: 40px;
        background: #fff;
        padding: 3px;
        -webkit-box-shadow: 0px -12px 21px -15px rgba(0, 0, 0, 0.1);
        -moz-box-shadow: 0px -12px 21px -15px rgba(0, 0, 0, 0.1);
        box-shadow: 0px -12px 21px -15px rgba(0, 0, 0, 0.1);
    }

    .footer-02 .subscribe-form .form-group {
        position: relative;
        margin-bottom: 0;
        border-radius: 0;
    }

    .footer-02 .subscribe-form .form-group input {
        background: transparent !important;
        border: none !important;
        outline: none !important;
        color: rgba(0, 0, 0, 0.3) !important;
        font-size: 16px;
        height: 20px;
        border-radius: 0;
    }

    .footer-02 .subscribe-form .form-group input::-webkit-input-placeholder {
        /* Chrome/Opera/Safari */
        color: rgba(0, 0, 0, 0.3) !important;
    }

    .footer-02 .subscribe-form .form-group input::-moz-placeholder {
        /* Firefox 19+ */
        color: rgba(0, 0, 0, 0.3) !important;
    }

    .footer-02 .subscribe-form .form-group input:-ms-input-placeholder {
        /* IE 10+ */
        color: rgba(0, 0, 0, 0.3) !important;
    }

    .footer-02 .subscribe-form .form-group input:-moz-placeholder {
        /* Firefox 18- */
        color: rgba(0, 0, 0, 0.3) !important;
    }

    .footer-02 .subscribe-form .form-group input:focus {
        outline: none !important;
        -webkit-box-shadow: none;
        box-shadow: none;
    }

    .footer-02 .subscribe-form .form-group .submit {
        color: #fff !important;
        display: block;
        width: 150px;
        height: 56px;
        font-size: 14px;
        background: #2900FF !important;
        border: none;
        letter-spacing: 1px;
        text-transform: uppercase;
        border-radius: 40px;
    }

    .footer-02 .subscribe-form .form-group .submit:hover,
    .footer-02 .subscribe-form .form-group .submit:focus {
        text-decoration: none !important;
        outline: none !important;
    }

    .footer-02 .partner-wrap {
        border-top: 1px solid rgba(255, 255, 255, 0.05);
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        padding: 1em 0;
    }

    .footer-02 .partner-wrap h3 {
        font-size: 14px;
        color: rgba(255, 255, 255, 0.4);
    }

    .footer-02 .partner-wrap .partner-name a {
        margin-right: 10px;
        font-size: 13px;
        text-transform: uppercase;
        color: rgba(255, 255, 255, 0.4);
    }

    .footer-02 .partner-wrap .partner-name a span {
        color: white;
    }

    .footer-02 .partner-wrap .btn-custom {
        font-size: 14px;
    }

    .footer-02 .border-left {
        border-color: rgba(255, 255, 255, 0.05) !important;
    }

    @media (max-width: 1199.98px) {
        .footer-02 .border-left {
            border: none;
        }
    }
    .social-link{
        padding-left: 0;
    list-style-type: none;
    margin-bottom: 0;
    }
    .social-link li{
        display:inline-block;
        margin-right:4px;
    }
    .social-link li a{
        
    width: 30px;
    height: 30px;
    text-align: center;
    color: #fff;
    /* background-color: #6b6b84; */
    font-size: 18px;
    position: relative;
    border-radius: 2px;
    }
</style>



</body>

</html>	<script src="https://hub.slikk.ai/assets/js/plugins.js"></script>
  <script src="https://hub.slikk.ai/assets/js/theme.js"></script>
  
  	<script>
			    $(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');       
        }
    );
});
			</script>	 
	</body>
</html>
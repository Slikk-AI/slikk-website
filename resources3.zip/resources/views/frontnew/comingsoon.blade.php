@extends('frontnew.layouts.layout')
@section('frontnew_content')
<style>
    @media(min-width:1020px){
        .margin{
        margin-left: 300px;
    margin-bottom: 200px;
    } 
    }
</style>
<header class="section-home-header">
    <div class="page-padding">
        <div class="padding-top padding-xxhuge">
            <div class="container-large">
                <div class="home-header_wrapper">
                    <div class="center-wrapper home-header_left-wrapper">
                        <div class="margin-top margin-small">
                            <h1 class="home-header_heading home-head margin"><span class="text-bg text-color-purple" style="text-align:center;">Coming Soon</span>
                                    </h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
@endsection
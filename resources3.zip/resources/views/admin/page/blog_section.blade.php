<div class="form-row ContentSectionData" style="display:none;">
							<div class="form-row border-section CopyContentSectionData" >
							<div class="form-group col-md-12 ">
								<p style="position: absolute;right: 1px;"><a href="javascript:void(0);" class="SectionSectionBox"  onclick="return removeSection(this);">Remove</a></p>
							  <h5 ><input type="checkbox" class="SectionShow" checked> Section <span class="SectionCounter"></span> : </h5>
							  
							  <input type="hidden" class="SectionSequence">
							  <input type="hidden" class="HiddenSectionType">
							  <input type="hidden" class="ReportSectionId">
							</div>
							<div class="form-group col-md-12 ">
							  <label for="SectionTitle">Section Title</label>
							  <input type="text" class="form-control SectionTitle"  placeholder="Section Title"   />
							  <div class="invalid-data invalid-SectionTitle"></div>
							</div>
							<div class="form-group col-md-12">
							  <label for="SectionContent">Section Content</label>
							   <textarea rows="6" class="form-control tinytextarea SectionContent" ></textarea>
							  <div class="invalid-data invalid-SectionContent"></div>
							</div>
							<div class="form-group col-md-12" style="display:none;">
							  <label for="SectionPrice">Price</label>
							  <input type="text" class="form-control SectionPrice"  placeholder="Price"   />
							  <div class="invalid-data invalid-SectionPrice"></div>
							</div>
							
							</div>
							
						</div>
						<div class="form-row ImageSectionData" style="display:none;">
						<div class="form-row border-section CopyImageSectionData" >
							<div class="form-group col-md-12 ">
							<p style="position: absolute;right: 1px;"><a href="javascript:void(0);" class="SectionSectionBox"  onclick="return removeSection(this);">Remove</a></p>
							  <h5 ><input type="checkbox" class="SectionShow" checked> Section <span class="SectionCounter"></span> : </h5>
							  
							  <input type="hidden" class="SectionSequence">
							  <input type="hidden" class="HiddenSectionType">
							  <input type="hidden" class="ReportSectionId">
							  
							</div>
							<div class="form-group col-md-12">
							  <label for="ImageTtile">Section Title</label>
							  <input type="text" class="form-control ImageTtile"  placeholder="Section Title"   />
							  <div class="invalid-data invalid-ImageTtile"></div>
							</div>
							<div class="form-group col-md-12">
							  <label for="SectionImage">Image</label><br>
							   <input type="file" class="SectionImage" placeholder="Image" accept="image/*" >
							   <input type="hidden" class="ReportHiddenImg">
							  <div class="invalid-data invalid-SectionImage"></div>
							</div>
							</div>
							
							
							
						</div>
						
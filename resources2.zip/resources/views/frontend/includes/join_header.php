<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="https://slikk.ai/img/Slikk-Icon.svg">

<link href="https://slikk.ai/assets/single/bootstrap.min.css" rel="stylesheet">
<script src="https://slikk.ai/assets/single/bootstrap.bundle.min.js"></script>
<script src="https://slikk.ai/assets/single/jquery.min.js"></script>
<script src="https://slikk.ai/assets/single/constant.js"></script>
<script src="https://slikk.ai/assets/single/functions.js"></script>
<script src="https://slikk.ai/assets/single/common.js"></script>
<link href="https://slikk.ai/assets/single/style.css" rel="stylesheet" type="text/css">
<title>Slikk</title>

  <body>
@extends('frontend.layouts.master')
@section('content')
<section class="wrapper">
    <div class="container pt-14 pt-md-16 text-center">
      <div class="row">
        <div class="col-md-10 col-lg-9 col-xl-8 col-xxl-7 mx-auto" style="margin-top: 10%;margin-bottom: 5%;">
          <h2 class="display-3  mt-5 mb-3 px-lg-8">Coming Soon</h2>
          
        </div>
        <!-- /column -->
      </div>
      <!-- /.row -->
     
    </div>
    <!-- /.container -->
  </section>


@endsection
